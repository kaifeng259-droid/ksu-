#!/system/bin/sh
# 一加Ace5 ColorOS 16.3.5 专属优化 永久生效版
# 开机早期post-fs-data安全窗口执行，零系统修改，卸载即完全复原

# ======================== 1. 彻底禁用logd，永久封死复活 ========================
[ -f '/system/bin/logd' ] && mount -o bind /dev/null /system/bin/logd
killall -9 logd 2>/dev/null
setprop persist.logd.enable 0

# ======================== 2. 彻底阻断OTA自动更新 ========================
[ -f '/system/bin/update_engine' ] && mount -o bind /dev/null /system/bin/update_engine
pkill -9 update_engine 2>/dev/null
setprop persist.ota.auto_download 0
setprop persist.sys.recovery_update 0
setprop persist.sys.coupdate 0
rm -rf /data/ota_package /cache/ota 2>/dev/null

# ======================== 3. 锁定开发者选项不被系统重置 ========================
settings put --user 0 global development_settings_enabled 1
settings put --user 0 global adb_enabled 1
setprop persist.dev.option.lock 1

# ======================== 4. 屏蔽冗余耗电服务、广告、数据收集 ========================
# 核心冗余进程查杀
pkill -9 smartscene preload sysmonitor hotstart 2>/dev/null
# 禁用负一屏/智能助手
pm disable --user 0 com.coloros.assistant 2>/dev/null
# 【新增】彻底关闭系统广告总开关
setprop persist.sys.oplus.ad_enable 0
setprop persist.sys.oplus.personalized_ad 0
setprop persist.ad.track 0
# 【新增】彻底关死用户体验计划/数据统计
setprop persist.sys.usage_stat_enable 0
setprop persist.oppo.collect 0
pm disable --user 0 com.oplus.statistics.rom 2>/dev/null
# 冗余服务开关锁定
setprop persist.sys.preload 0
setprop persist.sys.monitor 0
setprop persist.sys.hotstart 0

# ======================== 5. 内存/IO轻量优化（无副作用） ========================
[ -w '/proc/sys/kernel/sched_schedstats' ] && echo 0 > /proc/sys/kernel/sched_schedstats
[ -w '/sys/module/binder/parameters/debug_mask' ] && echo 0 > /sys/module/binder/parameters/debug_mask
[ -w '/proc/sys/vm/compact_unevictable_allowed' ] && echo 0 > /proc/sys/vm/compact_unevictable_allowed
