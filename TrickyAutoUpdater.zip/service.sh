#!/system/bin/sh
# 等待系统进入桌面，防止启动过早导致 pm 命令失效
while [ "$(getprop sys.boot_completed)" != "1" ]; do
    sleep 5
done

TARGET_FILE="/data/adb/tricky_store/target.txt"
# 确保目录存在
mkdir -p /data/adb/tricky_store

# 初始扫描：确保运行即同步一次
pm list packages | cut -f 2 -d ":" | sort > "$TARGET_FILE"
cp "$TARGET_FILE" /dev/pkg_list_old

while true; do
    # 1. 获取当前三方包名
    pm list packages | cut -f 2 -d ":" | sort > /dev/pkg_list_new
    
    # 2. 对比新旧文件是否有差异 (使用 md5sum 快速比对)
    OLD_HASH=$(md5sum /dev/pkg_list_old | cut -d ' ' -f 1)
    NEW_HASH=$(md5sum /dev/pkg_list_new | cut -d ' ' -f 1)

    if [ "$OLD_HASH" != "$NEW_HASH" ]; then
        # 3. 发现变化：覆盖 target.txt 并更新缓存
        cat /dev/pkg_list_new > "$TARGET_FILE"
        cp /dev/pkg_list_new /dev/pkg_list_old
        
        # 可选：记录日志到系统日志，方便调试
        #log -t TrickyUpdater "Detected app change. target.txt updated."
    fi

    # 4. 循环间隔 1 秒
    sleep 1
done
