##########################################################################################
#
# Magisk 模块安装脚本
#
##########################################################################################

# 1. 自动设置一些环境变量（由 Magisk 自动处理，保持默认即可）
SKIPMOUNT=false
PROPFILE=false
POSTFSDATA=false
LATESTARTSERVICE=true

# 2. 打印安装信息
print_modname() {
  ui_print "*******************************"
  ui_print "  Tricky Store 自动包名同步器  "
  ui_print "  作者: Gemini (AI)            "
  ui_print "*******************************"
}

# 3. 解压模块文件
on_install() {
  ui_print "- 正在解压文件..."
  unzip -o "$ZIPFILE" 'service.sh' -d "$MODPATH" >&2
}

# 4. 设置权限（非常重要）
set_permissions() {
  # 设置 service.sh 的执行权限，否则脚本无法启动
  set_perm_recursive "$MODPATH" 0 0 0755 0755
}
