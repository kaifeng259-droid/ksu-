#!/system/bin/sh

# 将 CPU 调速器设置为 schedutil

GOVERNOR="schedutil"
CPU_PATH="/sys/devices/system/cpu"
SUCCESS=0
FAIL=0

# 等待系统启动完成
until [ "$(getprop sys.boot_completed)" = "1" ]; do
    sleep 1
done
sleep 15

for cpu_dir in "$CPU_PATH"/cpu[0-9]*; do
    cpu=$(basename "$cpu_dir")
    gov_file="$cpu_dir/cpufreq/scaling_governor"

    if [ -f "$gov_file" ]; then
        old_governor=$(cat "$gov_file")
        echo "$GOVERNOR" > "$gov_file" 2>/dev/null
        new_governor=$(cat "$gov_file")

        if [ "$new_governor" = "$GOVERNOR" ]; then
            echo "  ✔ $cpu：$old_governor → $new_governor"
            SUCCESS=$((SUCCESS + 1))
        else
            echo "  ✘ $cpu：设置失败（当前值：$new_governor）"
            FAIL=$((FAIL + 1))
        fi
    else
        echo "  - $cpu：不支持频率调节，跳过"
    fi
done

echo ""
echo "完成：成功 $SUCCESS 个，失败 $FAIL 个"