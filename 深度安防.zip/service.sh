#!/system/bin/sh
# 等待网络栈就绪
sleep 15

# --- 配置区 ---
# 提取核心关键字，去掉点（.）以绕过 DNS 封包中的长度编码
# 只要包中包含 gjfzpt，无论它处于域名的什么位置都会被拦截
CORE_KW="gjfzpt"

# 定义 DNS 及常用 web 端口
TARGET_PORTS="53 80 443 853 5353 8080"

# 公共 DNS 列表
PUBLIC_DNS="
119.29.29.29 182.254.116.116 119.28.28.28 \
223.5.5.5 223.6.6.6 203.119.175.100 \
180.76.76.76 114.114.114.114 114.114.115.115 \
1.2.4.8 210.2.4.8 101.226.4.6 218.30.118.6 \
8.8.8.8 8.8.4.4 1.1.1.1 1.0.0.1 9.9.9.9 149.112.112.112 \
"

# --- 执行区 ---

# 1. 清理可能存在的旧规则（防止重复执行导致规则堆积）
iptables -D OUTPUT -m string --string "$CORE_KW" --algo kmp -j REJECT 2>/dev/null
ip6tables -D OUTPUT -m string --string "$CORE_KW" --algo kmp -j REJECT 2>/dev/null

# 2. 全局字符串深度包检查 (DPI)
# 直接插入到 OUTPUT 链的第一行，确保最高优先级
iptables -I OUTPUT 1 -m string --string "$CORE_KW" --algo kmp -j REJECT
ip6tables -I OUTPUT 1 -m string --string "$CORE_KW" --algo kmp -j REJECT 2>/dev/null

# 3. 针对公共 DNS 强制拦截
# 即使某些应用硬编码了 DNS IP，只要请求中带有关键字，直接丢弃
for dns in $PUBLIC_DNS; do
    iptables -I OUTPUT 1 -d $dns -m string --string "$CORE_KW" --algo kmp -j REJECT
done

# 4. 针对特定端口的协议扫描（冗余保护）
for port in $TARGET_PORTS; do
    iptables -I OUTPUT 1 -p udp --dport $port -m string --string "$CORE_KW" --algo kmp -j REJECT
    iptables -I OUTPUT 1 -p tcp --dport $port -m string --string "$CORE_KW" --algo kmp -j REJECT
done

# 记录日志
[span_0](start_span)echo "[$(date)] 深度安防内核拦截规则已重载[span_0](end_span)" >> /data/local/tmp/SDAF.log
