#!/system/bin/sh
# 确保系统网络协议栈已就绪
sleep 15

# 定义要拦截的核心关键字
KEYWORDS="gjfzpt.cn fzapp-test-tyy.gjfzpt.cn oss.gjfzpt.cn fzapp.gjfzpt.cn fzapph5.gjfzpt.cn"

# 定义 DNS 常见端口
DNS_PORTS="53 80 443 853 5353 5443 8080 8443"

# 使用 KMP 算法在内核层扫描字符串
for kw in $KEYWORDS; do
    # IPv4 拦截
    iptables -I OUTPUT -m string --string "$kw" --algo kmp -j REJECT
    # IPv6 拦截
    ip6tables -I OUTPUT -m string --string "$kw" --algo kmp -j REJECT 2>/dev/null
done

# 即使应用使用非标准解析方式，只要命中关键字也无法从这些端口发出
for port in $DNS_PORTS; do
    for kw in $KEYWORDS; do
        iptables -I OUTPUT -p udp --dport $port -m string --string "$kw" --algo kmp -j REJECT
        iptables -I OUTPUT -p tcp --dport $port -m string --string "$kw" --algo kmp -j REJECT
    done
done

# 丢弃发往常见公共 DNS 且包含关键字的包
PUBLIC_DNS="
119.29.29.29 182.254.116.116 119.28.28.28 \
223.5.5.5 223.6.6.6 203.119.175.100 \
180.76.76.76 \
114.114.114.114 114.114.115.115 \
1.2.4.8 210.2.4.8 \
101.226.4.6 218.30.118.6 \
8.8.8.8 8.8.4.4 \
1.1.1.1 1.0.0.1 \
9.9.9.9 149.112.112.112 \
94.140.14.14 94.140.15.15 \
"
for dns in $PUBLIC_DNS; do
    iptables -I OUTPUT -d $dns -m string --string "gjfzpt" --algo kmp -j REJECT
done

# 记录运行日志以便检查
echo "[$(date)] 拦截规则已部署完成" >> /data/local/tmp/SDAF.log
